import { LightningElement, api, wire } from 'lwc';
import getRevenueRecognitionMilestones from '@salesforce/apex/RevenueRecognition.calculateMilestones';

export default class RevenueRecognition extends LightningElement {
    @api recordId;  // Opportunity Id passed to the component
    milestones = [];
    totalRevenue = 0;  // Variable to store total revenue
    error;

    // Columns for the data table
    columns = [
        { label: 'Milestone', fieldName: 'milestoneName' },
        { label: 'Amount', fieldName: 'amount' },
        { label: 'Recognition Date', fieldName: 'recognitionDate', type: 'date' }
    ];

    // Fetch data when the component is loaded
    @wire(getRevenueRecognitionMilestones, { opportunityId: '$recordId' })
    wiredMilestones({ error, data }) {
        if (data) {
            this.milestones = data;
            // Calculate total revenue from the milestones
            this.totalRevenue = this.milestones.reduce((total, milestone) => total + milestone.amount, 0);
        } else if (error) {
            // If error occurs, store the error message
            this.error = error.body.message;
        }
    }
}
